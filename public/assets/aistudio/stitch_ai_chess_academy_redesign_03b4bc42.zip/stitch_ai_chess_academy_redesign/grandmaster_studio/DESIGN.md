---
name: Grandmaster Studio
colors:
  surface: '#0f131d'
  surface-dim: '#0f131d'
  surface-bright: '#353944'
  surface-container-lowest: '#0a0e18'
  surface-container-low: '#171b26'
  surface-container: '#1b1f2a'
  surface-container-high: '#262a35'
  surface-container-highest: '#313540'
  on-surface: '#dfe2f0'
  on-surface-variant: '#bbcabf'
  inverse-surface: '#dfe2f0'
  inverse-on-surface: '#2c303b'
  outline: '#86948a'
  outline-variant: '#3c4a42'
  surface-tint: '#4edea3'
  primary: '#4edea3'
  on-primary: '#003824'
  primary-container: '#10b981'
  on-primary-container: '#00422b'
  inverse-primary: '#006c49'
  secondary: '#ffb95f'
  on-secondary: '#472a00'
  secondary-container: '#ee9800'
  on-secondary-container: '#5b3800'
  tertiary: '#4cd7f6'
  on-tertiary: '#003640'
  tertiary-container: '#00b2d0'
  on-tertiary-container: '#003f4b'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#6ffbbe'
  primary-fixed-dim: '#4edea3'
  on-primary-fixed: '#002113'
  on-primary-fixed-variant: '#005236'
  secondary-fixed: '#ffddb8'
  secondary-fixed-dim: '#ffb95f'
  on-secondary-fixed: '#2a1700'
  on-secondary-fixed-variant: '#653e00'
  tertiary-fixed: '#acedff'
  tertiary-fixed-dim: '#4cd7f6'
  on-tertiary-fixed: '#001f26'
  on-tertiary-fixed-variant: '#004e5c'
  background: '#0f131d'
  on-background: '#dfe2f0'
  surface-variant: '#313540'
typography:
  headline-xl:
    fontFamily: Plus Jakarta Sans
    fontSize: 40px
    fontWeight: '700'
    lineHeight: 48px
    letterSpacing: -0.02em
  headline-xl-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 30px
    fontWeight: '700'
    lineHeight: 38px
    letterSpacing: -0.015em
  headline-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 28px
    fontWeight: '600'
    lineHeight: 36px
    letterSpacing: -0.015em
  headline-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 22px
    fontWeight: '600'
    lineHeight: 28px
    letterSpacing: -0.01em
  body-lg:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-md:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  body-sm:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 16px
  clock-display:
    fontFamily: JetBrains Mono
    fontSize: 36px
    fontWeight: '700'
    lineHeight: 40px
    letterSpacing: -0.04em
  clock-display-mobile:
    fontFamily: JetBrains Mono
    fontSize: 26px
    fontWeight: '700'
    lineHeight: 32px
    letterSpacing: -0.03em
  eval-display:
    fontFamily: JetBrains Mono
    fontSize: 15px
    fontWeight: '700'
    lineHeight: 20px
    letterSpacing: 0.02em
  notation-move:
    fontFamily: JetBrains Mono
    fontSize: 13px
    fontWeight: '500'
    lineHeight: 18px
    letterSpacing: -0.01em
  label-caps:
    fontFamily: JetBrains Mono
    fontSize: 11px
    fontWeight: '600'
    lineHeight: 14px
    letterSpacing: 0.08em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  gutter: 1rem
  gutter-desktop: 1.5rem
  margin: 1rem
  margin-desktop: 2rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2rem
---

## Brand & Style

The design system projects absolute strategic authority, cerebral immersion, and luxury athletic precision. It caters to competitive tournament players, master-level analysts, and ambitious learners seeking an elite digital environment. The interface balances high-density technical analysis with the calm, focused silence of a world championship hall.

Visually, the design style unifies Modernist Technical Precision with Subtle Glassmorphic Layering. High-contrast engine evaluation data sits within deep obsidian surfaces, framed by whisper-thin luminous borders. The atmosphere avoids juvenile gamification, favoring the disciplined refinement of fine chronographs and professional sports analytics consoles.

## Colors

The palette is engineered strictly for high-focus, prolonged dark-room study and fast blitz gameplay.

- **Foundational Surfaces:** Layered obsidian depths progress from base canvas (`#0A0D14`) to raised surface (`#10141E`), panel container (`#181F2E`), and elevated hover/active states (`#222B3D`).
- **Accent Primaries:** Tournament Emerald (`#10B981`, with hover `#34D399` and active `#059669`) provides affirmative feedback, move highlights, and high-impact CTAs.
- **Prestige Accents:** Champion Gold (`#F59E0B`) denotes master titles (GM, IM), trophy moments, and premium mastery paths.
- **Engine Analysis Spectrum:** Tactical classifications carry strict visual meaning:
  - Brilliant: `#06B6D4`
  - Great Move: `#3B82F6`
  - Best / Book: `#A855F7`
  - Inaccuracy: `#EAB308`
  - Mistake: `#F97316`
  - Blunder: `#EF4444`
- **Chessboard Themes:** Standard competition vinyl utilizes `#769656` (dark squares) and `#EEEED2` (light squares). The obsidian night alternate utilizes `#2C3545` (dark squares) and `#4F5D73` (light squares).
- **Text & Hierarchy:** Pure white (`#FFFFFF`) is reserved for primary numeric timers, turn alerts, and critical ratings. Subdued ivory (`#E2E8F0`) covers standard labels, while muted titanium (`#94A3B8`) handles historical algebraic notation.

## Typography

Typography establishes an uncompromising division between natural conversational UI and mechanical mathematical precision.

- **Plus Jakarta Sans** delivers polished confidence for major landmarks, modal headers, coaching insight titles, and system modules.
- **Inter** ensures crisp, neutral readability across chat transcripts, deep annotations, pedagogical explanations, and system settings.
- **JetBrains Mono** serves as the authoritative engine conduit. It handles all tabular metrics, algebraic move notations (`1. e4 e5 2. Nf3 Nc6`), clock countdowns, ELO metrics, and fractional engine balances (`+1.42`). It guarantees zero horizontal jitter during live time decrements.

## Layout & Spacing

The layout operates on an asymmetric 12-column desktop split tailored for synchronized desktop play:
- **Left Wing (Cols 1–2):** Persistent navigational spine, player profiles, and primary mode switches.
- **Center Arena (Cols 3–9):** Fixed-aspect square chessboard framed by player identity badges, live clocks, and the evaluation bar.
- **Right Wing (Cols 10–12):** Live move list, Stockfish engine lines, deep branching variations, and AI coach conversational suggestions.

On mobile/tablet breakpoints, the layout collapses into a single-column stacked hierarchy: opponent card, chessboard with integrated edge eval bar, player card + clock dock, followed by swipeable tabbed drawers for notations and engine reports.

Element spacing strictly follows a 4px/8px modular grid. Component margins never intrude on the chessboard's strict aspect ratio.

## Elevation & Depth

Visual hierarchy relies on calibrated surface luminescence and razor-thin borders rather than diffuse drop shadows.

- **Level 0 (Canvas Base):** Solid `#0A0D14`. Background for inactive layout regions.
- **Level 1 (Play Areas & Board Well):** `#10141E` with a hairline outline (`1px solid rgba(255, 255, 255, 0.05)`).
- **Level 2 (Panels & Move Log):** `#181F2E` with `backdrop-filter: blur(16px)` and micro-border (`1px solid rgba(255, 255, 255, 0.08)`).
- **Level 3 (Modals, Contextual Popovers, Engine Tooltips):** `#222B3D` resting over a `rgba(10, 13, 20, 0.8)` backdrop. Features an ambient border (`1px solid rgba(255, 255, 255, 0.12)`) and an ultra-soft directional rim: `0 12px 32px -4px rgba(0, 0, 0, 0.6)`.
- **Active Focus Glow:** Interactive elements receiving focus or currently active move indicators cast a controlled primary emerald rim (`box-shadow: 0 0 0 1px #10B981, 0 0 16px -2px rgba(16, 185, 129, 0.3)`).

## Shapes

The interface balances sharp tactical precision with ergonomic luxury:
- **Containers & Panels:** Rely on `rounded` (0.5rem / 8px) to establish architectural order without appearing clinical.
- **Chessboard Container:** Uses a micro-corner treatment (`rounded`, 8px) with zero border radius on individual internal board squares to ensure geometric play integrity.
- **Interactive Badges & ELO Pills:** Utilize full circular pill styling (`rounded-full`) to delineate metadata from actionable square buttons.

## Components

### Buttons
- **Primary:** Solid `#10B981` with dark text `#0A0D14`, bold weight, and a gentle transition to `#34D399` on hover. Used for "Find Match", "Review Game", and "Resign Confirmation".
- **Secondary / Action:** Translucent obsidian (`#181F2E`) with a 1px border (`rgba(255,255,255,0.08)`). Text in `#FFFFFF`. Hover triggers `#222B3D` and subtle emerald text shifts.
- **Analysis Control Buttons:** Compact square icon buttons (`36x36px`) for move stepping (`<<`, `<`, `>`, `>>`), flip board, and engine toggle.

### Digital Chess Clocks
- Dual high-contrast displays anchored above and below the board. Active clocks utilize bright `#FFFFFF` on a `#181F2E` base with an animated 2px emerald bottom-progress border. Inactive clocks drop to 50% opacity (`#94A3B8`). Time scramble states (sub-30s in blitz) trigger a pulsing Blunder Crimson accent glow (`#EF4444`).

### Live Evaluation Bar
- A vertical ribbon pinned adjacent to the board. Smooth physics-based height transition using dual tones: Light evaluation fills from top in `#EEEED2`, Dark evaluation anchors bottom in `#181F2E`. Centered miniature badge displays the numeric advantage (`+1.42` or `M3`) in bold `eval-display` mono typography.

### Move List & Notation Matrix
- Alternating zebra grid: Move numbers in muted slate (`#64748B`), moves in `#E2E8F0` with instantaneous highlight on the active half-move.
- Glyphs for analysis classifications (`!`, `!!`, `?`, `??`) are displayed as compact rounded badges colored to match the engine analysis tokens.

### Grandmaster AI Coach Badge
- Luxury glassmorphic card module with an obsidian gradient (`#181F2E` to `#10141E`). Topped with a subtle champion gold ring badge (`GM 2800`), an interactive wave dynamic voice indicator, and contextual hints displayed in `Inter` body text.

### Inputs & Selectors
- Flat `#10141E` backgrounds with inset `1px solid rgba(255,255,255,0.08)` borders. Focused states transition cleanly to `#10B981` outlines with zero layout shift.